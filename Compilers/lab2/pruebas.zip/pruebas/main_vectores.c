// main vectores
main() {
    int v[5];
    int x;
    v[0] = 10;
    x = v[0];
    return v[0] + v[1] + v[2];
}


// declaración de variable global
int x = 5;

//Función principal (main)
main() {
    int a = 3, b = 4;
    a = a + b;
    puts("Hola mundo");
}


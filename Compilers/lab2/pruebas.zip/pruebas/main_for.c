
// bucle for
main() {
    int i;
    for (i = 0; i < 3; i = i + 1) {
        puts("Hola");
    }
}



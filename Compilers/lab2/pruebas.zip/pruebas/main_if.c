// main - if anidado

main() {
    int x = 5;
    if (x > 0) {
        if (x < 10) {
            return x;
        }
    }
}

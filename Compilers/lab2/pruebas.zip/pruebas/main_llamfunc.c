
suma (int a, int b) {
    return a + b;
}


// main uso de funcion
main() {
    int r = suma(3, 4);
}
